// Declare the package.

package beans;

import java.io.Serializable;

/**
 * The PersonBean class is a simple JavaBean that holds data for a person.
 * It contains private fields, a no-argument constructor, and public getter and setter methods.
 * It implements the Serializable interface so it can be used in JSP and servlet-based environments.
 */
public class PersonBean implements Serializable {

    // Define private fields to store personal data
    private String firstName;  // Stores the person's first name
    private String lastName;   // Stores the person's last name
    private int age;           // Stores the person's age
    private String email;      // Stores the person's email address
    private String country;    // Stores the person's country

    /**
     * No-argument constructor
     */
    public PersonBean() {}

    // Getter and setter methods for each private field

    // First Name
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    // Last Name
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    // Age
    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    // Email
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // Country
    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
}